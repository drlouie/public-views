## This file contains the user specific variables
## necessary for Commerce.cgi


$sc_sales_tax = ".05";
$sc_sales_tax_state = "MA";
$sc_send_order_to_email = "yes";
$sc_order_log_name = "your_order.log";
$sc_send_order_to_log = "yes";
$shipping_percentage = ".10";
$sc_order_email = "richie\@careyinternet.com";
$sc_root_url = "http://www.careyinternet.com";
$sc_admin_email = "richie\@careyinternet.com";
$sc_domain_name_for_cookie = ".careyinternet.com";
$sc_order_script_url = "http://www.careyinternet.com/commerce/standard/cgi-bin/store/commerce.cgi";
$sc_root_web_path = "/home/carey/www/home/commerce/standard/Html/Products";
$sc_path_for_cookie = "/commerce/standard/cgi-bin/store";
$path_to_html = "../../home/Html";
