# This file contains the HTML for the store admin screens
#
######################################################################################

sub PageHeader

{
print <<ENDOFTEXT;

<HTML>
<BODY BGCOLOR=WHITE>
<CENTER>
<TABLE WIDTH=500>
<TR WIDTH=500>
<TD WIDTH=125>
<B>Ref. #</B>
</TD>
<TD WIDTH=125>
<B>Category</B>
</TD>
<TD WIDTH=125>
<B>Description</B>
</TD>
<TD WIDTH=125>
<B>Price</B>
</TD>
</TR>

ENDOFTEXT
}

######################################################################################

sub DisplayRequestedProduct

{

print <<ENDOFTEXT;


<TR WIDTH=500>
<TD WIDTH=125>
$sku
</TD>
<TD WIDTH=125>
$category
</TD>
<TD WIDTH=125>
$short_description
</TD>
<TD WIDTH=125>
$price
</TD>
</TR>

ENDOFTEXT

}

#######################################################################################

sub PageFooter
{

print <<ENDOFTEXT;

</TABLE>
</CENTER>
</BODY>
</HTML>

ENDOFTEXT

}

#######################################################################################

sub display_login
{
print <<ENDOFTEXT;

<HTML>
<HEAD>
<TITLE>Build an online store with Commerce.cgi</TITLE>

<META NAME="description" CONTENT="FREE shopping cart software - Commerce.cgi"> 
<META NAME="keywords" CONTENT="free, shopping cart, e-commerce, software, perl, 
database, easy, secure, store, dynamic, web based, c, c++, javascript, html">

</HEAD>
<BODY BGCOLOR="WHITE">

<CENTER>

<A HREF="http://www.careyinternet.com/">

<IMG SRC="http://www.careyinternet.com/main/images/cisLogo.gif" BORDER="0">

</a>

</CENTER>

<FORM METHOD=POST ACTION=manager.cgi>

<P>&nbsp;</P>

<CENTER>
<TABLE WIDTH=500 BORDER=0 CELLPADDING=2>

<TR>
<TD COLSPAN=2>
<HR WIDTH=550>
</TD>
</TR>

<TR>
<TD COLSPAN=2>Username:&nbsp;<INPUT TYPE=text NAME=username></TD>
</TR>
<TR>
<TD COLSPAN=2>Password:&nbsp;<INPUT TYPE=password NAME=password></TD>
</TR>

<TR>
<TD>&nbsp;</TD>
</TR>

<TR>
<TD COLSPAN=2>
<CENTER>
<INPUT TYPE=HIDDEN NAME="login" VALUE="yes">
<INPUT TYPE=HIDDEN NAME="welcome_screen" VALUE="yes">
<INPUT TYPE=submit VALUE=submit>&nbsp;<INPUT TYPE=reset VALUE=reset>
</CENTER>
</TD>
</TR>

</TABLE>
</CENTER>

</FORM>

<HR WIDTH=550>

<P>&nbsp;</P>

<CENTER>
<TABLE BORDER=0 CELLPADDING=0 CELLSPACING=0 WIDTH="550">
<TR>
<TD>
<IMG SRC="http://www.careyinternet.com/main/images/front_footer.gif" BORDER=0>
</TD>
</TR>
</TABLE>
</CENTER>
</BODY>
</HTML>

ENDOFTEXT

}

#######################################################################################

sub display_welcome_screen

{
print <<ENDOFTEXT;

<HTML>
<HEAD>
<TITLE>Commerce.cgi Store Manager</TITLE>
</HEAD>
<BODY BGCOLOR=WHITE>

<CENTER>
<TABLE WIDTH=550 BORDER=0>
<CENTER>
<TR WIDTH=550 BORDER=0>
<TD WIDTH=550 BORDER=0>
<CENTER>
<A HREF=http://www.careyinternet.com/>
<IMG SRC="http://www.careyinternet.com/main/images/cisLogo.gif" BORDER=0>
</a>
</CENTER>
</TD>
</TR>
</CENTER>
</TABLE>
</CENTER>

<CENTER>
<TABLE WIDTH=550 BORDER=0>
<TR WIDTH=550 BORDER=0>
<TD WIDTH=550 BORDER=0>
<CENTER>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?add_screen=yes>Add A Product</A>&nbsp;&nbsp;&nbsp;</FONT>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?edit_screen=yes>Edit A Product</A>&nbsp;&nbsp;&nbsp;</FONT>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?delete_screen=yes>Delete A Product</A>&nbsp;&nbsp;&nbsp;</FONT>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?change_settings_screen=yes>Program Settings</A>&nbsp;&nbsp;&nbsp;</FONT>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?tracking_screen=yes>View Tracking</A>&nbsp;&nbsp;&nbsp;</FONT>
</CENTER>
</TD>
</TR>
</TABLE>
</CENTER>

<HR WIDTH=550>

<CENTER>
<TABLE BORDER=0 CELLPADDING=0 CELLSPACING=0 WIDTH="550">
<TR WIDTH=275 HEIGHT=180>
<TD WIDTH=275 HEIGHT=180><FONT  FACE="Arial" SIZE=2>Welcome to the <b>Commerce.cgi</b> store manager. Managing a store has never been easier! Using your web browser, you can configure every aspect of your store right through the web. First up, the <b>Catalog Manager</b>, which allows you to add, edit, or remove products from your web site with ease. <A HREF=manager.cgi?add_screen=yes>Click here</a> to test it out.</FONT></TD>
<TD WIDTH=275 HEIGHT=180><CENTER><A HREF=manager.cgi?add_screen=yes><IMG SRC=http://www.careyinternet.com/program/images/cat_mng.gif WIDTH=202 HEIGHT=152 BORDER=0></a></CENTER></TD>
</TR>
</TABLE>
<CENTER>

<CENTER>
<TABLE>
<TR WIDTH=550>
<TD WIDTH=550><HR></TD>
</TR>
</TABLE>
</CENTER>

<CENTER>
<TABLE BORDER=0 CELLPADDING=0 CELLSPACING=0 WIDTH="550">
<TR WIDTH=275 HEIGHT=180>
<TD WIDTH=275 HEIGHT=180><CENTER><A HREF=manager.cgi?change_settings_screen=yes><IMG SRC=http://www.careyinternet.com/program/images/system_mng.gif WIDTH=202 HEIGHT=152 BORDER=0></a></CENTER></TD>
<TD WIDTH=275 HEIGHT=180><FONT  FACE="Arial" SIZE=2>Hate to dig through cryptic configuration files? <b>System Manager</b> lets you painlessly set several config variables unique to your store. Here you will add your e-mail address, the url to your secure server, and a few other key pieces of information. Check out the System Manager by <A HREF=manager.cgi?change_settings_screen=yes>Clicking Here</a></FONT>
</TD>
</TR>
</TABLE>
</CENTER>

<CENTER>
<TABLE>
<TR WIDTH=550>
<TD WIDTH=550><HR></TD>
</TR>
</TABLE>
</CENTER>

<CENTER>
<TABLE BORDER=0 CELLPADDING=0 CELLSPACING=0 WIDTH="550">
<TR WIDTH=275 HEIGHT=180>
<TD WIDTH=275 HEIGHT=180>
<FONT  FACE="Arial" SIZE=2>
The Commerce.cgi <b>Tracking Manager</b> is a great tool for monitoring your store's traffic. At a glance, you'll be able to check your store's most popular pages, track links from other web sites, determine which pages are being bookmarked, and more. You'll even be able to track the most popular web browsers used by your store's customers. Take a closer look at the <b>Tracking Manager</b> by <a href=manager.cgi?tracking_screen=yes>Clicking Here</a></FONT></TD>
<TD WIDTH=275 HEIGHT=180><CENTER><A HREF=manager.cgi?tracking_screen=yes><IMG SRC=http://www.careyinternet.com/program/images/tracking_mng.gif BORDER=0 WIDTH=202 HEIGHT=152></a></CENTER></TD>
</TR>
</TABLE>
</CENTER>
<BR>

<HR WIDTH=550>

<CENTER>

<table border=0 CELLPADDING=5 CELLSPACING=0>

<tr>

<td>
<FONT FACE="arial" size="2">
<a href="http://www.onelist.com/subscribe/commercecgi">Click here</a> to join the 
<strong>Commerce.cgi</strong> mailing list!
</FONT>
</td>

</tr>

</table>

</CENTER>

<HR WIDTH=550>

<CENTER>
<FONT FACE=ARIAL>
Need help? View the help file <a href=http://www.careyinternet.com/main/commerce/ReadMe.html>here</a></CENTER>
</FONT>
<CENTER>

<TABLE BORDER=0 CELLPADDING=0 CELLSPACING=0 WIDTH="550">
<TR>
<TD><IMG SRC=http://www.careyinternet.com/main/images/front_footer.gif BORDER=0></TD>
</TR>
</TABLE>
</CENTER>

</BODY>
</HTML>

ENDOFTEXT

}
#######################################################################################
sub add_product_screen

{
local($add_product_success) = @_;

##

local($sku, $category, $price, $short_description, $image, 
      $long_description, $options);

open (NEWSKU, "$datafile");

while(<NEWSKU>)

	{

($sku, $category, $price, $short_description, $image, 
 $long_description, $options) = split(/\|/,$_);

chop($options);

push(@sku_num,$sku);

	}

close(NEWSKU);

$highest_value = $sku_num[$#sku_num];
$highest_value++;
$new_sku = $highest_value;

##

print <<ENDOFTEXT;

<HTML>
<HEAD>
<TITLE>Add a New Product</TITLE>
</HEAD>
<BODY BGCOLOR=WHITE>
<CENTER>
<TABLE WIDTH=550 BORDER=0>
<CENTER>
<TR WIDTH=550 BORDER=0>
<TD WIDTH=550 BORDER=0>
<CENTER>
<A HREF=http://www.careyinternet.com/>
<IMG SRC="http://www.careyinternet.com/main/images/cisLogo.gif" BORDER=0>
</a>
</CENTER>
</TD>
</TR>
</CENTER>
</TABLE>
</CENTER>

<CENTER>
<TABLE WIDTH=550 BORDER=0>
<TR WIDTH=550 BORDER=0>
<TD WIDTH=550 BORDER=0>
<CENTER>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?add_screen=yes>Add A Product</A>&nbsp;&nbsp;&nbsp;</FONT>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?edit_screen=yes>Edit A Product</A>&nbsp;&nbsp;&nbsp;</FONT>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?delete_screen=yes>Delete A Product</A>&nbsp;&nbsp;&nbsp;</FONT>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?change_settings_screen=yes>Program Settings</A>&nbsp;&nbsp;&nbsp;</FONT>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?tracking_screen=yes>View Tracking</A>&nbsp;&nbsp;&nbsp;</FONT>
</CENTER>
</TD>
</TR>
</TABLE>
</CENTER>

<CENTER>
<HR WIDTH=500>
</CENTER>

<CENTER>
<TABLE WIDTH=500>
<TR>
<TD WIDTH=500>
<FONT FACE=ARIAL>
This is the Add-A-Product screen of the <b>Commerce.cgi</b> product manager. Just follow the directions and add products to your store right through your web browser.</TD>
</TR>
</TABLE>
</CENTER>

<CENTER>
<HR WIDTH=500>
</CENTER>

ENDOFTEXT

if($add_product_success eq "yes")

{

print <<ENDOFTEXT;

<CENTER>
<TABLE>
<TR>
<TD>
<FONT FACE=ARIAL SIZE=2 COLOR=RED>Product number <a href=../commerce.cgi?product=$in{'category'}>$in{'sku'}</a> has been added to the catalog.</FONT>
</TD>
</TR>
</TABLE>
</CENTER>

ENDOFTEXT

}

elsif($add_product_success eq "no")
{
print <<ENDOFTEXT;

<CENTER>
<TABLE>
<TR>
<TD>
<FONT FACE=ARIAL SIZE=2 COLOR=RED>Reference # already exists in datafile! Unable to add product, please choose a new Reference # number.</FONT>
</TD>
</TR>
</TABLE>
</CENTER>

ENDOFTEXT

} 
print <<ENDOFTEXT;

<BODY BGCOLOR=WHITE>
<FORM METHOD=POST ACTION=manager.cgi>
<CENTER>
<TABLE BORDER=1 CELLPADDING=5 CELLSPACING=1 WIDTH="550">
<TR>
<TD WIDTH=100><FONT FACE=ARIAL SIZE=2><b>$new_sku</b></FONT></TD>
<TD WIDTH=450><FONT FACE=ARIAL SIZE=2><b>Reference #</b></FONT></TD>
</TR>
<TR>
<TD WIDTH=100><INPUT NAME="category" TYPE="TEXT" SIZE=35 MAXLENGTH=35></TD>
<TD WIDTH=450><FONT FACE=ARIAL SIZE=2><b>Category</b> - One word only</font></TD>
</TR>
<TR>
<TD WIDTH=100><INPUT NAME="price" TYPE="TEXT" SIZE=35 MAXLENGTH=35></TD>
<TD WIDTH=450><FONT FACE=ARIAL SIZE=2><b>Price</b></font> - No \$ sign needed</TD>
</TR>
<TR>
<TD WIDTH=100><INPUT NAME="name" TYPE="TEXT" SIZE=35 MAXLENGTH=35></TD>
<TD WIDTH=450><FONT FACE=ARIAL SIZE=2><b>Product Name</b> - 3 or 4 words</font></TD>
</TR>
<TR>
<TD WIDTH=100><INPUT NAME="image" TYPE="TEXT" SIZE=35 MAXLENGTH=35></TD>
<TD WIDTH=450><FONT FACE=ARIAL SIZE=2><b>Image File</b> - filename.gif</font></TD>
</TR>
<TR>
<TD WIDTH=100><INPUT NAME="option_file" TYPE="TEXT" SIZE=35 MAXLENGTH=35></TD>
<TD WIDTH=450><FONT FACE=ARIAL SIZE=2><b>Option File</b> - filename.html</font></TD>
</TR>
<TR>
<TD WIDTH=100><TEXTAREA NAME="description" ROWS=6 COLS=35 wrap=soft></TEXTAREA></TD>
<TD WIDTH=450><FONT FACE=ARIAL SIZE=2><b>Description</b> - Enter the HTML (including price) for your product description here. </font></TD>
</TR>
</TABLE>
<TABLE WIDTH=550>
<TR WIDTH=550>
<TD WIDTH=550>
<INPUT TYPE=HIDDEN NAME=sku VALUE=$new_sku>
<CENTER>
<INPUT TYPE=SUBMIT NAME=AddProduct VALUE="Add Product">&nbsp;
<INPUT TYPE=RESET VALUE="Clear Form">
</CENTER>
</TD>
<TR>
</TABLE>
</CENTER>
</FORM>
</BODY>
</HTML>

ENDOFTEXT
}

#############################################################################################
sub edit_product_screen
{
print <<ENDOFTEXT;

<HTML>
<HEAD><TITLE>Edit Product Screen</TITLE></HEAD>
<BODY BGCOLOR=WHITE>
<CENTER>
<TABLE WIDTH=550 BORDER=0>
<CENTER>
<TR WIDTH=550 BORDER=0>
<TD WIDTH=550 BORDER=0>
<CENTER>
<A HREF="http://www.careyinternet.com/">
<IMG SRC="http://www.careyinternet.com/main/images/cisLogo.gif" BORDER=0>
</a>
</CENTER>
</TD>
</TR>
</CENTER>
</TABLE>
</CENTER>

<CENTER>
<TABLE WIDTH=550 BORDER=0>
<TR WIDTH=550 BORDER=0>
<TD WIDTH=550 BORDER=0>
<CENTER>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?add_screen=yes>Add A Product</A>&nbsp;&nbsp;&nbsp;</FONT>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?edit_screen=yes>Edit A Product</A>&nbsp;&nbsp;&nbsp;</FONT>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?delete_screen=yes>Delete A Product</A>&nbsp;&nbsp;&nbsp;</FONT>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?change_settings_screen=yes>Program Settings</A>&nbsp;&nbsp;&nbsp;</FONT>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?tracking_screen=yes>View Tracking</A>&nbsp;&nbsp;&nbsp;</FONT>
</CENTER>
</TD>
</TR>
</TABLE>
</CENTER>

<CENTER>
<HR WIDTH=500>
</CENTER>

<CENTER>
<TABLE WIDTH=500>
<TR>
<TD WIDTH=500>
<FONT FACE=ARIAL>
This is the Edit-A-Product screen of the <b>Commerce.cgi</b> product manager. Click the <b>'Edit'</b> to make 
changes to products in your catalog.</TR>
</TABLE>
</CENTER>

<CENTER>
<HR WIDTH=500>
</CENTER>

ENDOFTEXT

if ($in{'ProductEditSku'} ne "")
{
print <<ENDOFTEXT;
<CENTER>
<TABLE WIDTH=550 BORDER=0>
<CENTER>
<TR WIDTH=550 BORDER=0>
<TD WIDTH=550 BORDER=0>
<CENTER><FONT FACE=ARIAL SIZE=2 COLOR=RED>Reference \# $in{'ProductEditSku'} successfully edited</FONT></CENTER>
</TD>
</TR>
</CENTER>
</TABLE>
</CENTER>
ENDOFTEXT
}

print <<ENDOFTEXT;

<CENTER>

<TABLE WIDTH=550 BORDER=1>
	<TR WIDTH=550>
	<TD WIDTH=100>
	<b>Edit</b>
	</TD>
	<TD WIDTH=75>
	<B>Ref. #</B>
	</TD>

	<TD WIDTH=75>
	<B>Category</B>
	</TD>

	<TD WIDTH=225>
	<B>Description</B>
	</TD>

	<TD WIDTH=75>
	<B>Price</B>
	</TD>

	</TR>

ENDOFTEXT

###
open (DATABASE, "$datafile");

while(<DATABASE>)

	{

($sku, $category, $price, $short_description, $image, 
 $long_description, $options) = split(/\|/,$_);

chop($options);

foreach ($sku) {

###
print <<ENDOFTEXT;

	<TR WIDTH=550>
	<TD WIDTH=100>
	<CENTER>
	<FORM METHOD=POST ACTION=manager.cgi>
	<INPUT TYPE=SUBMIT NAME=EditProduct VALUE=" Edit ">
	<INPUT TYPE=HIDDEN NAME=EditWhichProduct VALUE=$sku>
	</FORM>
	</CENTER>
	</TD>
	<TD WIDTH=75>
	$sku
	</TD>

	<TD WIDTH=75>
	$category
	</TD>

	<TD WIDTH=225>
	$short_description
	</TD>

	<TD WIDTH=75>
	$price
	</TD>

	</TR>

ENDOFTEXT

# End of foreach
}

	} # End of while database

print <<ENDOFTEXT;

	</TABLE>

	</CENTER>
	</BODY>
	</HTML>

ENDOFTEXT

}

#############################################################################################

sub change_settings_screen
{
require "../Admin_files/commerce_user_lib.pl";

print <<ENDOFTEXT;
<HTML>
<HEAD>
<TITLE>System Manager</TITLE>
</HEAD>
<BODY BGCOLOR=WHITE>
<FORM METHOD="POST" ACTION="manager.cgi">

<CENTER>
<TABLE WIDTH=550 BORDER=0>
<CENTER>
<TR WIDTH=550 BORDER=0>
<TD WIDTH=550 BORDER=0>
<CENTER>
<A HREF=http://www.careyinternet.com/>
<IMG SRC="http://www.careyinternet.com/main/images/cisLogo.gif" BORDER=0>
</a>
</CENTER>
</TD>
</TR>
</CENTER>
</TABLE>
</CENTER>

<CENTER>
<TABLE WIDTH=550 BORDER=0>
<TR WIDTH=550 BORDER=0>
<TD WIDTH=550 BORDER=0>
<CENTER>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?add_screen=yes>Add A Product</A>&nbsp;&nbsp;&nbsp;</FONT>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?edit_screen=yes>Edit A Product</A>&nbsp;&nbsp;&nbsp;</FONT>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?delete_screen=yes>Delete A Product</A>&nbsp;&nbsp;&nbsp;</FONT>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?change_settings_screen=yes>Program Settings</A>&nbsp;&nbsp;&nbsp;</FONT>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?tracking_screen=yes>View Tracking</A>&nbsp;&nbsp;&nbsp;</FONT>
</CENTER>
</TD>
</TR>
</TABLE>
</CENTER>

<CENTER>
<HR WIDTH=500>
</CENTER>

<CENTER>
<TABLE WIDTH=500>
<TR>
<TD WIDTH=500>
<FONT FACE=ARIAL>Welcome to the <b>Commerce.cgi</b> System Manager. Here you will set the data variables specific to your store. 
Each value is defined and described, so you should have no problem getting through this part.
</TD>
</TR>
</TABLE>
</CENTER>

ENDOFTEXT

if($in{'system_edit_success'} ne "")
{
print <<ENDOFTEXT;
<CENTER>
<TABLE>
<TR>
<TD>
<FONT FACE=ARIAL SIZE=2 COLOR=RED>System settings have been successfully updated</FONT>
</TD>
</TR>
</TABLE>
</CENTER>
ENDOFTEXT
}

print <<ENDOFTEXT;

<FONT FACE=ARIAL SIZE=2>
<CENTER>
<TABLE BORDER=0 CELLPADDING=10 CELLSPACING=0 WIDTH=500 BORDER=0>

<TR>
<TD COLSPAN=2><HR></TD>
</TR>

<TR>
<TD COLSPAN=2>
If you have installed the program files in the directories specified in the 
<a href=http://www.careyinternet.com/main/commerce/ReadMe.html>Read Me</a>, you 
should not have to change this. This is the path to the <strong>/Html</strong> directory
relative to <strong>commerce.cgi</strong>. This is the toughest variable to set, so install
the files according to the directions if possible! :-)<br>
</TD>
</TR>

<TR>
<TD COLSPAN=2>
<INPUT NAME="path_to_html" TYPE="TEXT" SIZE=55 VALUE="$path_to_html"><br>
<b>Path to /Html directory</b>
</TD>
</TR>

<TR>
<TD COLSPAN=2><HR></TD>
</TR>

<TR>
<TD COLSPAN=2>
/Products path is the <b>Full Server Path</b> to the "Products" directory on your web server.
This is NOT the url path. If you are not sure what this, contact your your web hosting provider. An example is:<br>
<b>/mnt/web/guide/dial411/store/Html/Products</b> Note: NO Trailing /
</TD>
</TR>

<TR>
<TD COLSPAN=2>
<INPUT NAME="root_path" TYPE="TEXT" SIZE=55 VALUE="$sc_root_web_path"><br>
<b>Path to /Products directory</b>
</TD>
</TR>

<TR>
<TD COLSPAN=2><HR></TD>
</TR>

<TR>
<TD><INPUT NAME="sales_tax" TYPE="TEXT" VALUE="$sc_sales_tax" SIZE="5"></TD>
<TD>Enter sales tax percentage here. Enter as a decimal number. <br>
Ex: "<b>.05</b>" for "5%", "<b>.06</b>" for "6%", etc.<br>
</TD>
</TR>

<TR>
<TD COLSPAN=2><HR></TD>
</TR>

<TR>
<TD>
<SELECT NAME=sales_tax_state>
<OPTION>$sc_sales_tax_state</OPTION>
<OPTION>AL</OPTION> 
<OPTION>AK</OPTION> 
<OPTION>AZ</OPTION> 
<OPTION>AR</OPTION> 
<OPTION>CA</OPTION> 
<OPTION>CO</OPTION> 
<OPTION>CT</OPTION> 
<OPTION>DC</OPTION>
<OPTION>DE</OPTION> 
<OPTION>FL</OPTION> 
<OPTION>GA</OPTION> 
<OPTION>GU</OPTION> 
<OPTION>HI</OPTION> 
<OPTION>ID</OPTION> 
<OPTION>IL</OPTION> 
<OPTION>IN</OPTION> 
<OPTION>IA</OPTION> 
<OPTION>KS</OPTION> 
<OPTION>KY</OPTION> 
<OPTION>LA</OPTION> 
<OPTION>ME</OPTION> 
<OPTION>MD</OPTION> 
<OPTION>MA</OPTION> 
<OPTION>MI</OPTION> 
<OPTION>MN</OPTION> 
<OPTION>MS</OPTION> 
<OPTION>MO</OPTION> 
<OPTION>MT</OPTION> 
<OPTION>NE</OPTION> 
<OPTION>NV</OPTION> 
<OPTION>NH</OPTION> 
<OPTION>NJ</OPTION> 
<OPTION>NM</OPTION> 
<OPTION>NY</OPTION> 
<OPTION>NC</OPTION> 
<OPTION>ND</OPTION> 
<OPTION>OH</OPTION> 
<OPTION>OK</OPTION> 
<OPTION>OR</OPTION> 
<OPTION>PA</OPTION> 
<OPTION>PR</OPTION> 
<OPTION>RI</OPTION> 
<OPTION>SC</OPTION> 
<OPTION>SD</OPTION> 
<OPTION>TN</OPTION> 
<OPTION>TX</OPTION> 
<OPTION>UT</OPTION> 
<OPTION>VI</OPTION> 
<OPTION>VT</OPTION> 
<OPTION>VA</OPTION> 
<OPTION>WA</OPTION> 
<OPTION>WV</OPTION> 
<OPTION>WI</OPTION> 
<OPTION>WY</OPTION> 
</SELECT>
</TD>
<TD>
Customers from the state selected here will be charged sales tax
</TR>

<TR>
<TD COLSPAN=2><HR></TD>
</TR>

<TR>
<TD>
<SELECT NAME="email_orders_yes_no">
<OPTION>$sc_send_order_to_email</OPTION>
<OPTION>yes</OPTION>
<OPTION>no</OPTION>
</SELECT>
</TD>
<TD>Do you wish to have orders e-mailed to you?</TD>
</TR>

<TR>
<TD COLSPAN=2><HR></TD>
</TR>

<TR>
<TD>
<INPUT NAME="email_address_for_orders" TYPE="TEXT" VALUE="$sc_order_email">
</TD>
<TD>
Enter the e-mail address where you'd like the orders sent
</TR>

<TR>
<TD COLSPAN=2><HR></TD>
</TR>

<TR>
<TD>
<SELECT NAME="log_orders_yes_no">
<OPTION>$sc_send_order_to_log</OPTION>
<OPTION>yes</OPTION>
<OPTION>no</OPTION>
</SELECT>
</TD>
<TD>Do you wish to have the orders written to a log file?</TD>
</TR>

<TR>
<TD COLSPAN=2><HR></TD>
</TR>

<TR>
<TD>
<INPUT NAME="name_of_the_log_file" TYPE="TEXT" VALUE="$sc_order_log_name">
</TD>
<TD>
Choose a unique name for your log file.<br> (ex: "mylog3218.txt")
</TD>
</TR>

<TR>
<TD COLSPAN=2><HR></TD>
</TR>

<TR>
<TD>
<INPUT NAME="admin_email" TYPE="TEXT" VALUE="$sc_admin_email">
</TD>
<TD>
Enter the e-mail address of your webmaster or administrator here
</TD>
</TR>

<TR>
<TD COLSPAN=2><HR></TD>
</TR>

<TR>
<TD>
<INPUT NAME="shipping_percentage" TYPE="TEXT" VALUE="$shipping_percentage" SIZE=5>
</TD>
<TD>
One level of shipping is available and is calculated as a percentage of the total order. 
Enter as a decimal number.<br>
Ex: "<b>.05</b>" for "5%", "<b>.06</b>" for "6%", etc.
</TD>
</TR>

<TR>
<TD COLSPAN=2><HR></TD>
</TR>

<TR>
<TD COLSPAN=2>
Please enter the root url of your site here (ex: <b>http://www.dial411.com</b>)
</TD>
</TR>

<TR>
<TD COLSPAN=2>
<INPUT NAME="root_url" TYPE="TEXT" SIZE=55 VALUE="$sc_root_url"><br><b>Root URL</b>
</TD>
</TR>

<TR>
<TD COLSPAN=2><HR></TD>
</TR>

<TR>
<TD COLSPAN=2>
Cookie domain sets the domain name associated with the cookie. It needs to be in 
this exact form. Ex:<b> .dial411.com </b>
</TD>
</TR>

<TR>
<TD COLSPAN=2>
<INPUT NAME="cookie_domain" TYPE="TEXT" SIZE=55 VALUE="$sc_domain_name_for_cookie"><br>
<b>Cookie Domain</b>
</TD>
</TR>

<TR>
<TD COLSPAN=2><HR></TD>
</TR>

<TR>
<TD COLSPAN=2>
Cookie path sets the URL path associated with the cookie. If your store is located at 
'http://www.your_domain.com/users/store/commerce.cgi' This would be set to <b>/users/store</b>
</TD>
</TR>

<TR>
<TD COLSPAN=2>
<INPUT NAME="cookie_path" TYPE="TEXT" SIZE=55 VALUE="$sc_path_for_cookie"><br>
<b>Cookie Path</b>
</TD>
</TR>

<TR>
<TD COLSPAN=2><HR></TD>
</TR>

<TR>
<TD COLSPAN=2>Order URL is the complete URL of your secure server. An example would be:<br>
<b>https://commerce.dial411.com/store/commerce.cgi</b>
</TD>
</TR>

<TR>
<TD COLSPAN=2>
<INPUT NAME="order_url" TYPE="TEXT" SIZE=55 VALUE="$sc_order_script_url"><br>
<b>Order URL</b>
</TD>
</TR>

<TR>
<TD COLSPAN=2><HR></TD>
</TR>

<TR>
<TD COLSPAN=2>
<CENTER>
<INPUT TYPE="HIDDEN" NAME="system_edit_success" VALUE="yes">
<INPUT NAME="ChangeSettings" TYPE="SUBMIT" VALUE="Submit">
&nbsp;&nbsp;
<INPUT TYPE="RESET" VALUE="Reset">
</CENTER>
</TD>
</TR>

<TR>
<TD COLSPAN=2>
<HR>
</TD>
</TR>

</TABLE>

</CENTER>
</FORM>

</BODY>
</HTML>

ENDOFTEXT
}

#############################################################################################

sub tracking_screen
{

$| = 1;

print <<ENDOFTEXT;

<HTML>
<HEAD>
<TITLE>Tracking Manager</TITLE>
</HEAD>
<BODY BGCOLOR=WHITE>
<CENTER>
<TABLE WIDTH=550 BORDER=0>
<CENTER>
<TR WIDTH=550 BORDER=0>
<TD WIDTH=550 BORDER=0>
<CENTER>
<A HREF="http://www.careyinternet.com/">
<IMG SRC="http://www.careyinternet.com/main/images/cisLogo.gif" BORDER=0>
</a>
</CENTER>
</TD>
</TR>
</CENTER>
</TABLE>
</CENTER>

<CENTER>
<TABLE WIDTH=550 BORDER=0>
<TR WIDTH=550 BORDER=0>
<TD WIDTH=550 BORDER=0>
<CENTER>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?add_screen=yes>Add A Product</A>&nbsp;&nbsp;&nbsp;</FONT>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?edit_screen=yes>Edit A Product</A>&nbsp;&nbsp;&nbsp;</FONT>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?delete_screen=yes>Delete A Product</A>&nbsp;&nbsp;&nbsp;</FONT>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?change_settings_screen=yes>Program Settings</A>&nbsp;&nbsp;&nbsp;</FONT>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?tracking_screen=yes>View Tracking</A>&nbsp;&nbsp;&nbsp;</FONT>
</CENTER>
</TD>
</TR>
</TABLE>
</CENTER>

<CENTER>
<HR WIDTH=500>
</CENTER>

<CENTER>
<TABLE WIDTH=500>
<TR>
<TD WIDTH=500>
<FONT FACE=ARIAL>
Welcome to the <b>Commerce.cgi</b> Tracking Manager. Here you will learn some important information about 
your visitors and your store.
</FONT>
</TD>
</TR>
</TABLE>
<CENTER>

<CENTER>
<TABLE WIDTH=500>
<TR>
<TD>

<HR WIDTH=500>
<FONT FACE=ARIAL SIZE=2>
<h4>These are the pages that are linking to your store</h4><br>

ENDOFTEXT

$datafile = "../Admin_files/access.log";

open (DATABASE, "$datafile");

while(<DATABASE>)

	{

($url, $shortdate, $requested_page, $visit_number, $ip_address, $browser_type, 
 $referring_page, $unix_date) = split(/\|/, $_);

# keep the urls 110 characters or less for better display
$referring_page = substr($referring_page, 0, 110);
$requested_page = substr($requested_page, 0, 110);

foreach ($referring_page) {

	if ($requested_page ne "")
	{
	$referring_page_count{$referring_page}++;
	}
}

#####
foreach ($requested_page) {

	if ($referring_page eq "possible bookmarks"){

	if ($requested_page ne "")
	{
	$count_bookmarked_pages{$requested_page}++;
	}

}	
#####
foreach ($requested_page) {

	if ($requested_page ne ""){

	$count_first_hit_pages{$requested_page}++;
	}

}
#####
foreach ($ip_address) {

	if ($ip_address ne ""){

	$count_ip{$ip_address}++;
	}

}
#####
foreach ($visit_number) {

	if ($visit_number ne ""){

	$count_visit{$visit_number}++;
	}

}
#####
foreach ($browser_type) {

	if ($browser_type ne ""){

	$count_browser{$browser_type}++;
	}

}
#####

}
	}

close DATABASE;

###########################################

foreach $referring_page (sort { $referring_page_count{$b} <=> $referring_page_count{$a} } keys %referring_page_count) {

if ($referring_page_count{$referring_page} > 1)

{
print <<ENDOFTEXT;

$referring_page_count{$referring_page} visits from <a href=$referring_page>$referring_page</a><br>

ENDOFTEXT
}

}


###########################################

print <<ENDOFTEXT;

<BR>
<CENTER>
<HR WIDTH=500>
</CENTER>
<BR>

<h4>These pages appear to be accessed directly, <br>possibly through a bookmark.</h4><br>
ENDOFTEXT

foreach $requested_page (sort { $count_bookmarked_pages{$b} <=> $count_bookmarked_pages{$a} } keys %count_bookmarked_pages) {

if ($count_bookmarked_pages{$requested_page} > 1)

{
print <<ENDOFTEXT;

$count_bookmarked_pages{$requested_page} visits to <a href=$requested_page>$requested_page</a><br>

ENDOFTEXT
}

}

##########################################

print <<ENDOFTEXT;

<BR>
<CENTER>
<HR WIDTH=500>
</CENTER>
<BR>

<h4>These pages were accessed first during visits to your store</h4><br>
ENDOFTEXT

foreach $requested_page (sort { $count_first_hit_pages{$b} <=> $count_first_hit_pages{$a} } keys %count_first_hit_pages) {

if ($count_first_hit_pages{$requested_page} > 1)

{
print <<ENDOFTEXT;

$count_first_hit_pages{$requested_page} first visits to <a href=$requested_page>$requested_page</a><br>

ENDOFTEXT
}

}

##########################################

print <<ENDOFTEXT;

<BR>
<CENTER>
<HR WIDTH=500>
</CENTER>
<BR>

<h4>I.P. Addresses of the visitors to your store.</h4><br>
ENDOFTEXT

foreach $ip_address (sort { $count_ip{$b} <=> $count_ip{$a} } keys %count_ip) {

if ($count_ip{$ip_address} > 1)

{
print <<ENDOFTEXT;

$count_ip{$ip_address} visitors from I.P. address <a href=http://$ip_address>$ip_address</a>.<br>

ENDOFTEXT
}

}

##########################################

print <<ENDOFTEXT;

<BR>
<CENTER>
<HR WIDTH=500>
</CENTER>
<BR>

<h4>Web browsers your visitors are using.</h4><br>
ENDOFTEXT

foreach $browser_type (sort { $count_browser{$b} <=> $count_browser{$a} } keys %count_browser) {

if ($count_browser{$browser_type} > 1)

{
print <<ENDOFTEXT;

$count_browser{$browser_type} visitors use $browser_type as a web browser.<br>

ENDOFTEXT
}

}

#########################################

print <<ENDOFTEXT;

<BR>
<CENTER>
<HR WIDTH=500>
</CENTER>
<BR>

</FONT>
</TD>
</TR>
</TABLE>
</CENTER>
</BODY>

ENDOFTEXT

}

#############################################################################################

sub delete_product_screen
{
print <<ENDOFTEXT;

<HTML>
<HEAD>
<TITLE>Delete Product Screen</TITLE>
<SCRIPT>
function WarnDelete()
{
alert("Please proceed with caution! Clicking the Delete button will immediately remove a product from your catalog");
}
</SCRIPT>
</HEAD>
<BODY BGCOLOR=WHITE onLoad="WarnDelete()">
<CENTER>
<TABLE WIDTH=550 BORDER=0>
<CENTER>
<TR WIDTH=550 BORDER=0>
<TD WIDTH=550 BORDER=0>
<CENTER>
<A HREF="http://www.careyinternet.com/">
<IMG SRC="http://www.careyinternet.com/main/images/cisLogo.gif" BORDER=0>
</a>
</CENTER>
</TD>
</TR>
</CENTER>
</TABLE>
</CENTER>

<CENTER>
<TABLE WIDTH=550 BORDER=0>
<TR WIDTH=550 BORDER=0>
<TD WIDTH=550 BORDER=0>
<CENTER>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?add_screen=yes>Add A Product</A>&nbsp;&nbsp;&nbsp;</FONT>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?edit_screen=yes>Edit A Product</A>&nbsp;&nbsp;&nbsp;</FONT>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?delete_screen=yes>Delete A Product</A>&nbsp;&nbsp;&nbsp;</FONT>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?change_settings_screen=yes>Program Settings</A>&nbsp;&nbsp;&nbsp;</FONT>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?tracking_screen=yes>View Tracking</A>&nbsp;&nbsp;&nbsp;</FONT>
</CENTER>
</TD>
</TR>
</TABLE>
</CENTER>

<CENTER>
<HR WIDTH=500>
</CENTER>

<CENTER>
<TABLE WIDTH=500>
<TR>
<TD WIDTH=500>
<FONT FACE=ARIAL COLOR=RED>
WARNING!</FONT>
<FONT FACE=ARIAL>Clicking the <b>'Delete'</b> button will IMMEDIATELY remove that product from your catalog.
You've been warned! :-)
</TD>
</TR>
</TABLE>
</CENTER>

<CENTER>
<HR WIDTH=500>
</CENTER>

ENDOFTEXT

if ($in{'DeleteWhichProduct'} ne "")
{
print <<ENDOFTEXT;
<CENTER>
<TABLE WIDTH=550 BORDER=0>
<CENTER>
<TR WIDTH=550 BORDER=0>
<TD WIDTH=550 BORDER=0>
<CENTER><FONT FACE=ARIAL SIZE=2 COLOR=RED>Reference \# $in{'DeleteWhichProduct'} successfully deleted</FONT></CENTER>
</TD>
</TR>
</CENTER>
</TABLE>
</CENTER>
ENDOFTEXT
}

print <<ENDOFTEXT;

<CENTER>

<TABLE WIDTH=550 BORDER=1>
	<TR WIDTH=550>
	<TD WIDTH=100><CENTER>
	<b><FONT COLOR=RED>Delete</FONT></b></CENTER>
	</TD>
	<TD WIDTH=75>
	<B>Ref. #</B>
	</TD>

	<TD WIDTH=75>
	<B>Category</B>
	</TD>

	<TD WIDTH=225>
	<B>Description</B>
	</TD>

	<TD WIDTH=75>
	<B>Price</B>
	</TD>

	</TR>

ENDOFTEXT

###
open (DATABASE, "$datafile");

while(<DATABASE>)

	{

($sku, $category, $price, $short_description, $image, 
 $long_description, $options) = split(/\|/,$_);

chop($options);

foreach ($sku) {

###
print <<ENDOFTEXT;

	<TR WIDTH=550>
	<TD WIDTH=100>
	<CENTER>
	<FORM METHOD=POST ACTION=manager.cgi>
	<INPUT TYPE=SUBMIT NAME=DeleteProduct VALUE="Delete">
	<INPUT TYPE=HIDDEN NAME=DeleteWhichProduct VALUE=$sku>
	</FORM>
	</CENTER>
	</TD>
	<TD WIDTH=75>
	$sku
	</TD>

	<TD WIDTH=75>
	$category
	</TD>

	<TD WIDTH=225>
	$short_description
	</TD>

	<TD WIDTH=75>
	$price
	</TD>

	</TR>

ENDOFTEXT

# End of foreach
}

	} # End of while database

print <<ENDOFTEXT;

	</TABLE>

	</CENTER>
	</BODY>
	</HTML>

ENDOFTEXT
}
#############################################################################################
sub display_perform_edit_screen
{
print <<ENDOFTEXT;

<HTML>
<HEAD>
<TITLE>Edit Product</TITLE>
</HEAD>
<BODY BGCOLOR=WHITE>
<FORM METHOD=POST ACTION=manager.cgi>
<CENTER>
<TABLE WIDTH=550 BORDER=0>
<CENTER>
<TR WIDTH=550 BORDER=0>
<TD WIDTH=550 BORDER=0>
<CENTER>
<A HREF="http://www.careyinternet.com/">
<IMG SRC="http://www.careyinternet.com/main/images/cisLogo.gif" BORDER=0>
</a>
</CENTER>
</TD>
</TR>
</CENTER>
</TABLE>
</CENTER>

<CENTER>
<TABLE WIDTH=550 BORDER=0>
<TR WIDTH=550 BORDER=0>
<TD WIDTH=550 BORDER=0>
<CENTER>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?add_screen=yes>Add A Product</A>&nbsp;&nbsp;&nbsp;</FONT>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?edit_screen=yes>Edit A Product</A>&nbsp;&nbsp;&nbsp;</FONT>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?delete_screen=yes>Delete A Product</A>&nbsp;&nbsp;&nbsp;</FONT>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?change_settings_screen=yes>Program Settings</A>&nbsp;&nbsp;&nbsp;</FONT>
<FONT FACE=ARIAL SIZE=2><A HREF=manager.cgi?tracking_screen=yes>View Tracking</A>&nbsp;&nbsp;&nbsp;</FONT>
</CENTER>
</TD>
</TR>
</TABLE>
</CENTER>

<CENTER>
<HR WIDTH=500>
</CENTER>

<CENTER>
<TABLE WIDTH=500>
<TR>
<TD WIDTH=500>
<FONT FACE=ARIAL>
Make changes to your product using this form. When you are satisfied with your changes, click <b>'Submit Edit'</b> below.
</FONT>
</TD>
</TR>
</TABLE>
</CENTER>

<CENTER>
<HR WIDTH=500>
</CENTER>

<CENTER>
<TABLE BORDER=1 CELLPADDING=5 CELLSPACING=1 WIDTH="550">
<TR>
<TD WIDTH=100><b>$sku</b></TD>
<TD WIDTH=450><FONT FACE=ARIAL SIZE=2><b>Reference #</b></FONT></TD>
</TR>
<TR>
<TD WIDTH=100><INPUT NAME="category" TYPE="TEXT" SIZE=35 MAXLENGTH=35 VALUE="$category"></TD>
<TD WIDTH=450><FONT FACE=ARIAL SIZE=2><b>Category</b> - One word only</font></TD>
</TR>
<TR>
<TD WIDTH=100><INPUT NAME="price" TYPE="TEXT" SIZE=35 MAXLENGTH=35 VALUE="$price"></TD>
<TD WIDTH=450><FONT FACE=ARIAL SIZE=2><b>Price</b></font> - No \$ sign needed</TD>
</TR>
<TR>
<TD WIDTH=100><INPUT NAME="name" TYPE="TEXT" SIZE=35 MAXLENGTH=35 VALUE="$short_description"></TD>
<TD WIDTH=450><FONT FACE=ARIAL SIZE=2><b>Product Name</b> - 3 or 4 words</font></TD>
</TR>
<TR>
<TD WIDTH=100><INPUT NAME="image" TYPE="TEXT" SIZE=35 MAXLENGTH=35 VALUE="$image"></TD>
<TD WIDTH=450><FONT FACE=ARIAL SIZE=2><b>Image File</b> - filename.gif</font></TD>
</TR>
<TR>
<TD WIDTH=100><INPUT NAME="option_file" TYPE="TEXT" SIZE=35 MAXLENGTH=35 VALUE="$options"></TD>
<TD WIDTH=450><FONT FACE=ARIAL SIZE=2><b>Option File</b> - filename.html</font></TD>
</TR>
<TR>
<TD WIDTH=100><TEXTAREA NAME="description" ROWS=6 COLS=35 wrap=soft>$long_description</TEXTAREA></TD>
<TD WIDTH=450><FONT FACE=ARIAL SIZE=2><b>Description</b> - Enter the HTML (including price) for your product description here. </font></TD>
</TR>
</TABLE>
<TABLE WIDTH=550>
<TR WIDTH=550>
<TD WIDTH=550>
<CENTER><INPUT TYPE=HIDDEN NAME="ProductEditSku" VALUE="$sku"></CENTER>
<CENTER><INPUT TYPE=SUBMIT NAME="SubmitEditProduct" VALUE="Submit Edit">&nbsp;<INPUT TYPE=RESET VALUE="Clear Form"></CENTER>
</TD>
<TR>
</TABLE>
</CENTER>
</FORM>
</BODY>
</HTML>

ENDOFTEXT

}
#############################################################################################
1;