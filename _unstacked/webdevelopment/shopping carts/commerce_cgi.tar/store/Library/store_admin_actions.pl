#######################################################################################
# This file contains the action logic for the store admin program
#
#######################################################################################
# commerce_user_lib.pl
#######################################################################################
sub action_process_login
{

if($in{'username'} eq "$username" && $in{'password'} eq "$password")
{
open(FILE, ">$ip_file") || die "Can't Open $ip_file";
print(FILE "\$ok_ip=\"$ENV{'REMOTE_ADDR'}\";\n");
close(FILE);
}

else
{
&display_login;
exit;
}

}
#######################################################################################

sub action_add_product
{
local($sku, $category, $price, $short_description, $image, 
      $long_description, $options);

open (CHECKSKU, "$datafile");

while(<CHECKSKU>)

	{

($sku, $category, $price, $short_description, $image, 
 $long_description, $options) = split(/\|/,$_);

chop($options);

foreach ($sku) {

if ($sku eq $in{'sku'})
{
#print "sku already exists!";
$add_product_status="no";
&add_product_screen($add_product_status);
exit;
}
			
# End of foreach
}



# End of while CHECKSKU

	}

close (CHECKSKU);

$formatted_description = $in{'description'};
$formatted_description =~ s/\r/ /g;
$formatted_description =~ s/\t/ /g;
$formatted_description =~ s/\n/ /g;

##
if ($in{'image'} ne "")
{
$formatted_image = "\<IMG SRC\=\"$path_to_html\/Images\/$in{'image'}\" BORDER\=0\>";
}
else
{
$formatted_image = "\<IMG SRC\=\"$path_to_html\/Images\/notavailable.gif\" BORDER\=0\>";
}

##
if ($in{'option_file'} ne "")

{
	if (-e "../$path_to_html/Options/$in{'option_file'}")
	{
	$formatted_option_file = "\%\%OPTION\%\%$in{'option_file'}";
	}
	else
	{
	$formatted_option_file = "\%\%OPTION\%\%blank.html";
	}
}

else

{
$formatted_option_file = "\%\%OPTION\%\%blank.html";
}
##

open (NEW, "+>> $datafile");

print (NEW  "$in{'sku'}|$in{'category'}|$in{'price'}|$in{'name'}|$formatted_image|$formatted_description|$formatted_option_file\n");

close(NEW);

$add_product_status="yes";
&add_product_screen($add_product_status);

}
#######################################################################################

sub display_catalog_screen

{
&PageHeader;

open (DATABASE, "$datafile");

while(<DATABASE>)

	{

($sku, $category, $price, $short_description, $image, 
 $long_description, $options) = split(/\|/,$_);

chop($options);

foreach ($sku) {

	#if ($sku eq $in{'sku'})
	#{
	&DisplayRequestedProduct;
	#}

# End of foreach
}



# End of while DATABASE

	}

close(DATABASE);

&PageFooter;
}

#######################################################################################
sub action_edit_product
{
local($sku, $category, $price, $short_description, $image, 
      $long_description, $options);

open (CHECKSKU, "$datafile");

while(<CHECKSKU>)

	{

($sku, $category, $price, $short_description, $image, 
 $long_description, $options) = split(/\|/,$_);

chop($options);

foreach ($sku) {

if ($sku eq $in{'EditWhichProduct'})
{

$options =~ s/%%OPTION%%//g;
$image =~ s/.*Html\/Images\///g;
$image =~ s/.gif.*/.gif/g;
$image =~ s/.jpg.*/.jpg/g;

&display_perform_edit_screen;
}

# End of foreach
}
# End of while
}

}
#######################################################################################
sub action_submit_edit_product
{
### Begin
local($sku, $category, $price, $short_description, $image, 
      $long_description, $options);

$formatted_description = $in{'description'};
$formatted_description =~ s/\r/ /g;
$formatted_description =~ s/\t/ /g;
$formatted_description =~ s/\n/ /g;

##
if ($in{'image'} ne "")
{
$formatted_image = "\<IMG SRC\=\"$path_to_html\/Images\/$in{'image'}\" BORDER\=0\>";
}
else
{
$formatted_image = "\<IMG SRC\=\"$path_to_html\/Images\/notavailable.gif\" BORDER\=0\>";
}

##
if ($in{'option_file'} ne "")

{
	if (-e "../$path_to_html/Options/$in{'option_file'}")
	{
	$formatted_option_file = "\%\%OPTION\%\%$in{'option_file'}";
	}
	else
	{
	$formatted_option_file = "\%\%OPTION\%\%blank.html";
	}
}

else

{
$formatted_option_file = "\%\%OPTION\%\%blank.html";
}
##

open(OLDFILE, "$datafile") || die "Can't Open $datafile";
@lines = <OLDFILE>;
#print @lines;

open(NEWFILE,">$datafile") || die "Can't Open $datafile";

foreach $line (@lines)
	{
($sku, $category, $price, $short_description, $image, 
 $long_description, $options) = split(/\|/,$line);

if ($sku == $in{'ProductEditSku'})
{
print (NEWFILE  "$in{'ProductEditSku'}|$in{'category'}|$in{'price'}|$in{'name'}|$formatted_image|$formatted_description|$formatted_option_file\n");
}

else 
{
print NEWFILE $line;
}

	}

close (NEWFILE);



&edit_product_screen;

### End
}

#######################################################################################

sub action_delete_product
{
### Begin
local($sku, $category, $price, $short_description, $image, 
      $long_description, $options);

open(OLDFILE, "$datafile") || die "Can't Open $datafile";
@lines = <OLDFILE>;

open(NEWFILE,">$datafile") || die "Can't Open $datafile";

foreach $line (@lines)
	{
($sku, $category, $price, $short_description, $image, 
 $long_description, $options) = split(/\|/,$line);

if ($sku == $in{'DeleteWhichProduct'})
{
$line = "";
}

else 
{
print NEWFILE $line;
}

	}

close (NEWFILE);



&delete_product_screen;

### End
}
#######################################################################################
sub action_change_settings

{
$user_settings = "../Admin_files/commerce_user_lib.pl";
local($admin_email, $order_email);
&ReadParse;

$order_email = $in{'email_address_for_orders'}; 
$order_email =~ s/\@/\\@/;

$admin_email = $in{'admin_email'};
$admin_email =~ s/\@/\\@/;

open (SETTINGS, "> $user_settings");

print (SETTINGS  "## This file contains the user specific variables\n");
print (SETTINGS  "## necessary for Commerce.cgi\n");
print (SETTINGS  "\n");
print (SETTINGS  "\n");
print (SETTINGS  "\$sc_sales_tax = \"$in{'sales_tax'}\";\n");
print (SETTINGS  "\$sc_sales_tax_state = \"$in{'sales_tax_state'}\";\n");
print (SETTINGS  "\$sc_send_order_to_email = \"$in{'email_orders_yes_no'}\";\n");
print (SETTINGS  "\$sc_order_log_name = \"$in{'name_of_the_log_file'}\";\n");
print (SETTINGS  "\$sc_send_order_to_log = \"$in{'log_orders_yes_no'}\";\n");
print (SETTINGS  "\$shipping_percentage = \"$in{'shipping_percentage'}\";\n");
print (SETTINGS  "\$sc_order_email = \"$order_email\";\n");
print (SETTINGS  "\$sc_root_url = \"$in{'root_url'}\";\n");
print (SETTINGS  "\$sc_admin_email = \"$admin_email\";\n");
print (SETTINGS  "\$sc_domain_name_for_cookie = \"$in{'cookie_domain'}\";\n");
print (SETTINGS  "\$sc_order_script_url = \"$in{'order_url'}\";\n");
print (SETTINGS  "\$sc_root_web_path = \"$in{'root_path'}\";\n");
print (SETTINGS  "\$sc_path_for_cookie = \"$in{'cookie_path'}\";\n");
print (SETTINGS  "\$path_to_html = \"$in{'path_to_html'}\";\n");
print (SETTINGS  "1\;\n");
close(SETTINGS);

&change_settings_screen;

}

#######################################################################################

1;