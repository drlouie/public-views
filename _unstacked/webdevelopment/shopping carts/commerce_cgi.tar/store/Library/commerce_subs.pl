###########################################################################################
sub SetCookies
{

###########################################################################################
# After requiring the cookie-lib.pl library which contains the routines for setting and   #
# reading cookies, this first section sets the necessary cookies within the visitors      #
# browser.                                                                                #
###########################################################################################
# Set the $domain to the domain of the server running this script exactly as shown. Then,
# set the path to the directory of web_store.cgi. If you don't set the path, your cookie
# would be returned to any site on that domain.
###########################################################################################

$cookie{'cart_id'} = "$cart_id";

# Set the domain to be correct for your domain

$domain = $sc_domain_name_for_cookie;
$secureDomain = $sc_secure_domain_name_for_cookie;

# The path to your 'store' directory

$path = $sc_path_for_cookie;
$securePath = $sc_secure_path_for_cookie;

# Leave this as is.

$secure = "";

# Cookie will expire in 24 hours

$now = time;

# Second in twenty four hours

$twenty_four_hours = "86400";

$expiration = $now+$twenty_four_hours;#number of days until cookie expires


if(!$form_data{'secure'})
{
&set_cookie($expiration,$domain,$path,$secure);
}
else
{
&set_cookie($expiration,$secureDomain,$securePath,$secure);
}

} 

############################################################################################

sub StoreHeader
{
 open (HEADER, "$sc_store_header_file");
  while (<HEADER>)
    {
    s/%%pathToImages%%/$path_to_html\/Images/g;
    print $_;
    }
  close (HEADER);
}

############################################################################################

sub StoreFooter
{
 open (FOOTER, "$sc_store_footer_file");
  while (<FOOTER>)
    {
    s/%%pathToImages%%/$path_to_html\/Images/g;
    print $_;
    }
  close (FOOTER);
}

############################################################################################

sub define_shipping_logic

{

$shipping_price = &format_price($shipping_percentage*$subtotal);

return $shipping_price;

}
############################################################################################

sub printSubmitPage

{
local($invoice_number, $customer_number);

$invoice_number = time;
$customer_number = $form_data{'cart_id'};
$customer_number =~ s/_/./g;

print <<ENDOFTEXT;
<INPUT TYPE=HIDDEN NAME=LOGIN VALUE=\"$sc_authorizenet_username\">
<INPUT TYPE=HIDDEN NAME=TYPE VALUE=\"NA\">
<INPUT TYPE=HIDDEN NAME=DISABLERECEIPT VALUE=\"TRUE\">
<INPUT TYPE=HIDDEN NAME=METHOD VALUE=\"$form_data{'18-type_of_card'}\">
<INPUT TYPE=HIDDEN NAME=CARDNUM VALUE=\"$form_data{'20-card_number'}\">
<INPUT TYPE=HIDDEN NAME=EXPDATE VALUE=\"$form_data{'21-ex_date'}\">
<INPUT TYPE=HIDDEN NAME=INVOICE VALUE=\"$invoice_number\">
<INPUT TYPE=HIDDEN NAME=DESCRIPTION VALUE=\"Commerce.cgi Order\">
<INPUT TYPE=HIDDEN NAME=CUSTID VALUE=\"$customer_number\">
<INPUT TYPE=HIDDEN NAME=NAME VALUE=\"$form_data{'01-fname'} $form_data{'02-lname'}\">
<INPUT TYPE=HIDDEN NAME=ADDRESS VALUE=\"$form_data{'03-b_street_address'}\">
<INPUT TYPE=HIDDEN NAME=CITY VALUE=\"$form_data{'04-b_city'}\">
<INPUT TYPE=HIDDEN NAME=STATE VALUE=\"$form_data{'05-b_state'}\">
<INPUT TYPE=HIDDEN NAME=ZIP VALUE=\"$form_data{'06-b_zip'}\">
<INPUT TYPE=HIDDEN NAME=COUNTRY VALUE=\"$form_data{'07-b_country'}\">
<INPUT TYPE=HIDDEN NAME=PHONE VALUE=\"$form_data{'13-phone'}\">
<INPUT TYPE=HIDDEN NAME=FAX VALUE=\"$form_data{'14-fax'}\">
<INPUT TYPE=HIDDEN NAME=EMAIL VALUE=\"$form_data{'15-e-mail'}\">
<!--Shipping Address-->
<INPUT TYPE=HIDDEN NAME=USER1 VALUE=\"$form_data{'08-m_street_adress'}\">
<INPUT TYPE=HIDDEN NAME=USER2 VALUE=\"$form_data{'09-m_city'}\">
<INPUT TYPE=HIDDEN NAME=USER3 VALUE=\"$form_data{'10-m_state'}\">
<INPUT TYPE=HIDDEN NAME=USER4 VALUE=\"$form_data{'11-m_zip'}\">
<INPUT TYPE=HIDDEN NAME=USER5 VALUE=\"$form_data{'12-m_country'}\">
<INPUT TYPE=HIDDEN NAME=USER6 VALUE=\"$cart_id\">
<INPUT TYPE=HIDDEN NAME=USER7 VALUE=\"$form_data{'$final_shipping'}\">
<INPUT TYPE=HIDDEN NAME=USER8 VALUE=\"$form_data{'$final_discount'}\">
<INPUT TYPE=HIDDEN NAME=USER9 VALUE=\"$form_data{'$final_sales_tax'}\">
<INPUT TYPE=HIDDEN NAME=USER10 VALUE=\"$form_data{''}\">
<INPUT TYPE=HIDDEN NAME=RESPONSECODE VALUE=\"T\">

<FONT FACE=ARIAL SIZE=-1>
<CENTER>
<TABLE WIDTH=500 BORDER=0 BGCOLOR=YELLOW>

<TR>
<TD COLSPAN=2>
<FONT FACE=ARIAL SIZE=-1>
<B>Customer Information</B>
</FONT>
</TD>
</TR>

<TR>
<TD WIDTH=100>
<FONT FACE=ARIAL SIZE=-1>
Customer Number
</FONT>
</TD>
<TD WIDTH=400>
<FONT FACE=ARIAL SIZE=-1>
$form_data{'cart_id'}
</FONT>
</TD>
</TR>

<TR>
<TD WIDTH=150>
<FONT FACE=ARIAL SIZE=-1>
Order Number
</FONT>
</TD>
<TD WIDTH=350>
<FONT FACE=ARIAL SIZE=-1>
$time
</FONT>
</TD>
</TR>

<TR>
<TD WIDTH=150>
<FONT FACE=ARIAL SIZE=-1>
Name
</FONT>
</TD>
<TD WIDTH=350>
<FONT FACE=ARIAL SIZE=-1>
$form_data{'01-fname'} $form_data{'02-lname'}
</FONT>
</TD>
</TR>

<TR>
<TD COLSPAN=2>
<FONT FACE=ARIAL SIZE=-1>
<B>Billing Address</B>
</FONT>
</TD>
</TR>

<TR>
<TD WIDTH=150>
<FONT FACE=ARIAL SIZE=-1>
Street
</FONT>
</TD>
<TD WIDTH=350>
<FONT FACE=ARIAL SIZE=-1>
$form_data{'03-b_street_address'}
</FONT>
</TD>
</TR>

<TR>
<TD WIDTH=150>
<FONT FACE=ARIAL SIZE=-1>
City
</FONT>
</TD>
<TD WIDTH=350>
<FONT FACE=ARIAL SIZE=-1>
$form_data{'04-b_city'}
</FONT>
</TD>
</TR>

<TR>
<TD WIDTH=150>
<FONT FACE=ARIAL SIZE=-1>
State
</FONT>
</TD>
<TD WIDTH=350>
<FONT FACE=ARIAL SIZE=-1>
$form_data{'05-b_state'}
</FONT>
</TD>
</TR>

<TR>
<TD WIDTH=150>
<FONT FACE=ARIAL SIZE=-1>
Zip
</FONT>
</TD>
<TD WIDTH=350>
<FONT FACE=ARIAL SIZE=-1>
$form_data{'06-b_zip'}
</FONT>
</TD>
</TR>

<TR>
<TD WIDTH=150>
<FONT FACE=ARIAL SIZE=-1>
Country
</FONT>
</TD>
<TD WIDTH=350>
<FONT FACE=ARIAL SIZE=-1>
$form_data{'07-b_country'}
</FONT>
</TD>
</TR>

<TR>
<TD WIDTH=150>
<FONT FACE=ARIAL SIZE=-1>
Phone
</FONT>
</TD>
<TD WIDTH=350>
<FONT FACE=ARIAL SIZE=-1>
$form_data{'13-phone'}
</FONT>
</TD>
</TR>

<TR>
<TD WIDTH=150>
<FONT FACE=ARIAL SIZE=-1>
Fax
</FONT>
</TD>
<TD WIDTH=350>
<FONT FACE=ARIAL SIZE=-1>
$form_data{'14-fax'}
</FONT>
</TD>
</TR>

<TR>
<TD WIDTH=150>
<FONT FACE=ARIAL SIZE=-1>
E-Mail
</FONT>
</TD>
<TD WIDTH=350>
$form_data{'15-e-mail'}
</TD>
</TR>

<!--Shipping Address-->

<TR>
<TD COLSPAN=2>
<FONT FACE=ARIAL SIZE=-1>
<B>Shipping Address</B>
</FONT>
</TD>
</TR>

<TR>
<TD WIDTH=150>
<FONT FACE=ARIAL SIZE=-1>
Street
</FONT>
</TD>
<TD WIDTH=350>
<FONT FACE=ARIAL SIZE=-1>
$form_data{'08-m_street_adress'}
</FONT>
</TD>
</TR>

<TR>
<TD WIDTH=150>
<FONT FACE=ARIAL SIZE=-1>
City
</FONT>
</TD>
<TD WIDTH=350>
<FONT FACE=ARIAL SIZE=-1>
$form_data{'09-m_city'}
</FONT>
</TD>
</TR>

<TR>
<TD WIDTH=150>
<FONT FACE=ARIAL SIZE=-1>
State
</FONT>
</TD>
<TD WIDTH=350>
<FONT FACE=ARIAL SIZE=-1>
$form_data{'10-m_state'}
</FONT>
</TD>
</TR>

<TR>
<TD WIDTH=150>
<FONT FACE=ARIAL SIZE=-1>
Zip
</FONT>
</TD>
<TD WIDTH=350>
<FONT FACE=ARIAL SIZE=-1>
$form_data{'11-m_zip'}
</FONT>
</TD>
</TR>

<TR>
<TD WIDTH=150>
<FONT FACE=ARIAL SIZE=-1>
Country
</FONT>
<TD>
<FONT FACE=ARIAL SIZE=-1>
$form_data{'12-m_country'}
</FONT>
</TD>
</TR>

<TR>
<TD COLSPAN=2>
<CENTER>
<P>
<INPUT TYPE=SUBMIT VALUE="Submit Order For Processing">
<P>
</CENTER>
</TD>
</TR>
</TABLE>
</CENTER>
</FONT>
ENDOFTEXT
}
############################################################################################

sub logOrder {
local($subtotal, $total_quantity,
      $total_measured_quantity,
      $text_of_cart,
      $required_fields_filled_in, $product, $quantity, $options);
                # 
                # First, we output the header of
                # the processing of the order
                # 
print qq!
<HTML>
<HEAD>
<TITLE>Thank you for your order</TITLE>
</HEAD>
</BODY>
!;

&StoreHeader;
                # We display the cart table.
                # This also has the effect of 
                # populating the text_of_cart
                # variable with the ASCII text version
                # of the cart for emailing/logging
                # the order that is being processed.
                # 

$text_of_cart .= "  --PRODUCT INFORMATION--\n\n";

open (CART, "$sc_cart_path") ||
 &file_open_error("$sc_cart_path",
                  "display_cart_contents", __FILE__, __LINE__);
while (<CART>)
	{
	$cartData++;
	@cart_fields = split (/\|/, $_);
	$quantity = $cart_fields[0];
	$product_price = $cart_fields[3];
	$product = $cart_fields[4];
	$options = $cart_fields[6];
	$options =~ s/<br>//g;
	$text_of_cart .= "Quantity:      $quantity\nProduct:       $product $sc_money_symbol $product_price\n";
	$text_of_cart .= "Options:       $options\n\n";
	}
close(CART);

	$text_of_confirm_email .= "Thank you for your order. We appreciate your business and will do everything we can to meet your expectations. Please visit us again soon!\n\n";

	$text_of_confirm_email .= $text_of_cart;
	$text_of_confirm_email .= "\n";

	$text_of_cart .= "  --ORDER INFORMATION--\n\n";
	$text_of_cart .= "INVOICE:       $form_data{'INVOICE'}\n";
	$text_of_confirm_email .= "INVOICE:       $form_data{'INVOICE'}\n";

	if ($form_data{'SHIPPING'})
	{
	$text_of_cart .= "SHIPPING:      $form_data{'SHIPPING'}\n";
	$text_of_confirm_email .= "SHIPPING:      $form_data{'SHIPPING'}\n";

	}

	if ($form_data{'DISCOUNT'})
	{
	$text_of_cart .= "DISCOUNT:      $form_data{'DISCOUNT'}\n";
	$text_of_confirm_email .= "DISCOUNT:      $form_data{'DISCOUNT'}\n";
	}

	if ($form_data{'SALESTAX'})
	{
	$text_of_cart .= "SALES TAX:     $form_data{'SALESTAX'}\n";
	$text_of_confirm_email .= "SALES TAX:     $form_data{'SALESTAX'}\n";
	}

	$text_of_cart .= "TOTAL:         $form_data{'AMOUNT'}\n";
	$text_of_confirm_email .= "TOTAL:         $form_data{'AMOUNT'}\n";

	$text_of_cart .= "METHOD:        $form_data{'METHOD'}\n";
	$text_of_cart .= "NUMBER:        $form_data{'CARDNUM'}\n";
	$text_of_cart .= "EXP:           $form_data{'EXPDATE'}\n";
	$text_of_cart .= "TYPE:          $form_data{'TYPE'}\n";
	$text_of_cart .= "DESCRIPTION:   $form_data{'DESCRIPTION'}\n";
	$text_of_cart .= "CUSTID:        $form_data{'CUSTID'}\n";
	$text_of_cart .= "NAME:          $form_data{'NAME'}\n";
	$text_of_cart .= "ADDRESS:       $form_data{'ADDRESS'}\n";
	$text_of_cart .= "CITY:          $form_data{'CITY'}\n";
	$text_of_cart .= "STATE:         $form_data{'STATE'}\n";
	$text_of_cart .= "ZIP:           $form_data{'ZIP'}\n";
	$text_of_cart .= "COUNTRY:       $form_data{'COUNTRY'}\n";
	$text_of_cart .= "PHONE:         $form_data{'PHONE'}\n";
	$text_of_cart .= "FAX:           $form_data{'FAX'}\n";
	$text_of_cart .= "EMAIL:         $form_data{'EMAIL'}\n";
	$text_of_cart .= "SHIP STREET:   $form_data{'USER1'}\n";
	$text_of_cart .= "SHIP CITY:     $form_data{'USER2'}\n";
	$text_of_cart .= "SHIP STATE:    $form_data{'USER3'}\n";
	$text_of_cart .= "SHIP ZIP:      $form_data{'USER4'}\n";
	$text_of_cart .= "SHIP COUNTRY:  $form_data{'USER5'}\n";
	$text_of_cart .= "USER6:         $form_data{'USER6'}\n";
	$text_of_cart .= "USER7:         $form_data{'USER7'}\n";
	$text_of_cart .= "USER8:         $form_data{'USER8'}\n";
	$text_of_cart .= "USER9:         $form_data{'USER9'}\n";
	$text_of_cart .= "USER10:        $form_data{'USER10'}\n";

  if ($sc_use_pgp =~ /yes/i) {
    &require_supporting_libraries(__FILE__, __LINE__,
      "$sc_pgp_lib_path");
  $text_of_cart = &make_pgp_file($text_of_cart,
                  "$sc_pgp_temp_file_path/$$.pgp");
  $text_of_cart = "\n" . $text_of_cart . "\n";
  }

                # 
                # Now that we have the text of the cart
                # all together. We check the required
                # form fields from the previous form
                # to see if they were filled in by the user
                # 
                # $required_fields_filled_in is set to "yes"
                # and remains this way until any ONE 
                # required field is missing -- at which
                # point it is set to no.
                # 

                # Since the required fields were
                # filled in correctly, we process
                # the rest of the order
                # 
                # 

  if ($sc_send_order_to_email =~ /yes/i) {
    &send_mail($sc_order_email,$sc_order_email,
               "Commerce.cgi Order", $text_of_cart);
  }

                # If we are sending the order to
                # a log file. Then, we use the following
                # routine to append to the log file
                # specified in the setup.
                # 
                # The entries in the log file
                # are separated by two lines of
                # 40 hyphens ("-" x 40)
                # 

  if ($sc_send_order_to_log =~ /yes/i) {
    open (ORDERLOG, "+>>./Admin_files/$sc_order_log_name");
    print ORDERLOG "-" x 60 . "\n";
    print ORDERLOG $text_of_cart;
    print ORDERLOG "-" x 60 . "\n";
    close (ORDERLOG);
  }

                # The user is notified that the order
                # was a success

if ($cartData)
{
&send_mail($sc_admin_email, $form_data{'EMAIL'}, "Thank you for your order!", "$text_of_confirm_email");
}
  
print <<ENDOFTEXT;
<CENTER>
<TABLE WIDTH=500>
<TR>
<TD WIDTH=500>
<FONT FACE=ARIAL>
Thank you for shopping with us. Your order has been received and will be 
shipped as soon as possible. Please visit us again soon!<br>
<P>&nbsp;</P>
<a href=commerce.cgi>Return To Front Page</a>
<P>&nbsp;</P>
<P>&nbsp;</P>
</FONT>
</TD>
</TR>
</TABLE>
<CENTER>  

ENDOFTEXT

# This empties the cart after the order is successful

open (CART, ">$sc_cart_path");
close (CART);

# and the footer is printed

&StoreFooter;

print qq!
</BODY>
</HTML>
!;

} # End of process_order_form


1;