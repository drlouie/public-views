$sc_product_display_row = qq~

<TR WIDTH=550> 
  
<TD ALIGN=CENTER WIDTH=125>

<CENTER>
<FONT FACE=ARIAL SIZE=2>
<FORM METHOD = "post" ACTION = "$sc_main_script_url">
<INPUT TYPE = "hidden" NAME = "cart_id" VALUE = "$form_data{'cart_id'}">
<INPUT TYPE = "hidden" NAME = "product" VALUE = "$form_data{'product'}">
<INPUT TYPE = "hidden" NAME = "keywords" VALUE = "$form_data{'keywords'}">
<SELECT NAME = "item-%s">
<OPTION VALUE = "">Select Quantity
<OPTION VALUE = "1"> 1
<OPTION VALUE = "2"> 2
<OPTION VALUE = "3"> 3
<OPTION VALUE = "4"> 4
<OPTION VALUE = "5"> 5
</SELECT>
</FONT>
<BR>
<INPUT TYPE = "submit" NAME = "add_to_cart_button" VALUE = "Add To Cart">
</CENTER>

</TD>

<TD ALIGN=CENTER WIDTH=150>%s</TD>
  
<TD WIDTH=275><FONT FACE=ARIAL SIZE=2>%s<BR>%s</FONT></TD>

</FORM>

</TR>

<TR> 
<TD COLSPAN = "3">
<A HREF=commerce.cgi?add_to_cart_button=yes&product=$form_data{'product'}&cart_id=$form_data{'cart_id'}&keywords=$form_data{'keywords'}&viewOrder=yes>
<FONT FACE=ARIAL>Check Out
</FONT>
</A>
</TD>
</TR>

<TR> 
<TD COLSPAN = "3"><HR></TD>
</TR>~;

###################################################################################

if ($form_data{'viewOrder'} eq "yes")
{
$sc_should_i_display_cart_after_purchase = "yes";
}
else
{
$sc_should_i_display_cart_after_purchase = "no";
}

1;