##############################################################################
# iTransact Corporation RediCart v3.9.2                                      #
# Copyright � iTransact Corporation.  All rights reserved.                   #
##############################################################################

##############################################################################
# This script contains code written and owned by iTransact Corporation and   #
# has been modified to enable merchants to have credit card and check        #
# transactions authorized and guaranteed online in real-time using           #
# iTransact's Transaction Gateway.  This script is provided free of charge.  #
# Please visit us at http://www.itransact.com                                #
#                                                                            #
# iTransact Transaction Gateway, RediCharge, RediCheck, and RediCart are     #
# trademarks of iTransact Corporation.  Other product and company names      #
# mentioned herein may be the trademarks of their respective owners.         #
#                                                                            #
# THIS SCRIPT IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER       #
# EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES  #
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. #
# TECHNICAL SUPPORT FOR THIS SCRIPT WILL NOT BE PROVIDED BY ITRANSACT        #
# CORPORATION                                                                #
#                                                                            #
# ITRANSACT CORPORATION TAKES NO RESPONSIBILITY FOR ANY DAMAGES SUFFERED AS  #
# A RESULT OF USING, MODIFYING OR  DISTRIBUTING THIS SOFTWARE.  IN NO EVENT  #
# WILL ITRANSACT CORPORATION BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, #
# OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE    #
# DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY,         #
# ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE, EVEN IF ITRANSACT  #
# HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.                       #
##############################################################################

######################
# AUTHOR INFORMATION #
#                    #########################################################
# S-Mart Shopping Cart Script v1.9                                           #
# Shop smart. Shop S-Mart.                                                   #
# Written by Barry Robison. (brobison@rcinet.com)                            #
# This script uses code written by Matt Wright.                              #
# Please visit his site at http://worldwidemart.com                          #
# Selling the code for this program without prior written consent of the     #
# author(s) is  expressly forbidden.  Obtain permission before               #
# redistributing this software over the Internet or in any other medium.     #
# In all cases copyright and header must remain intact.                      #
#                                                                            #
# All customization requests to be sent to brobison@rcinet.com.              #
##############################################################################

Use of this script requires some knowledge of HTML.  Since these scripts are
available free of charge, and were not written by iTransact Corporation,
no technical support is offered.

###########################
# INSTALLATION PROCEDURES #		
###########################

Notes: 
    You may need to contact your system administrator or ISP for help regarding installation.
    These scripts were written and tested for UNIX systems only.  Modifications will be
    necessary if you plan to use these scripts with Windows NT.

1.  You must first download these files from http://www.itransact.com/redicart/index.html.
    Please make sure that the file names are as follows.  If you downloaded the zip file, you
    may not need to rename the files.
    A. smart.txt - Rename to smart.cgi.
    B. config.txt - Rename to smart.cfg.
    C. valid.txt - Rename to valid.cgi.
    D. header.html
    E. footer.html
    F  example.html (Example shopping cart page.)
    G. readme.txt (This file.)

2.  Modify the header.html and footer.html documents.
    A. The header.html document may contain your graphics, wording, etc.  It is displayed
       on every page of the shopping cart.
    B. The footer.html must be modified to include the correct link path to your smart.cgi.

3.  Modify the smart.cgi, smart.cfg, and valid.cgi files.
    A. The first line of each of these scripts shows "#!/usr/bin/perl".
       The path must point to the Perl intrepreter on your system.  Ask your system
       administrator or ISP for the correct path, or type 'which perl' at the UNIX telnet
       prompt.  No other modification to smart.cgi and valid.cgi are necessary.
    B. Follow the directions in the smart.cfg script.  You must customize this script
       before it is uploaded to your server.

4.  Upload these files to your web server.  (Ascii format.)
    A. Create a directory called 'redicart' on your web server under your cgi-bin directory.
    B. Upload smart.cgi, smart.cfg, and valid.cgi into this directory.
    C. Create a directory called 'redicart' on your web server in your WWW area.
       Example: The directory would be http://www.foo.com/redicart
    D. Upload header.html and footer.html into this directory.
	
5.  Set the following permissions:
    A. Telnet to your server. (i.e. telnet www.foo.com)
    B. Go to the directory where you uploaded the files in step 4.
    C. Use the UNIX command 'chmod' the set these permissions:
        chmod 755 *.cgi
    D. Do not close your telnet session.

6.  Create the 'tmp' and 'orders' directories.
    A. Use the UNIX command 'mkdir' to create the following directories.
        tmp
        orders
    B. Set the permissions to both directories as 777.
        chmod 777 tmp
        chmod 777 orders

7.  That's it.  You can test your installation by pointing your browser to:
    http://www.foo.com/cgi-bin/smart.cgi?command=review
    You should at least see your header and footer.

8.  After the installation is complete, you may build your online store.  Your store
    may consist of as many pages as you wish, but you must include the necessary HTML
    tags to call the shopping cart scripts.  These tags are described below.  You may
    also refer to the example.html document.  The HTML tags are built into the page already.
    As shown in the example.html file, you should include links at the bottom of each page
    to REVIEW CART, PURCHASE ITEMS IN CART, and MAIN PAGE.  You can, of course, change the
    wording.  To get ideas on how to implement the shopping cart, you can view sites
    using ShopSmart at http://www.rcinet.com/~brobison/scripts/sites.html.

###################
# COMMON PROBLEMS #		
###################

1.  "Permission Denied"
    This generally indicates that the permissions for the scripts are not configured correctly.

2.  "Internal Server Error"
    This generally indicates that the PERL path at the top of each script is incorrect.
    Refer to Installation Procedure 2.

3.  Various errors when using scripts with Windows NT.
    These scripts were written and tested on UNIX only.  If you experience problems installing
    or using these scripts with Windows NT, please consult your NT system admin.

###########################
# HTML TAG SPECIFICATIONS #
###########################

As shown in the example.html order form, these HTML tags can be used:

* To show the current cart use this url:
   http://www.foo.com/cgi-bin/smart.cgi?command=review

* To purchase the items in the cart use this:
   http://www.foo.com/cgi-bin/smart.cgi?command=buy1

When creating order pages in your store, each item must contain these HTML tags:

  <form method=post action="http://www.foo.com/cgi-bin/smart.cgi?command=add">
  <input type=hidden name="itemname" value="Item Name">
  <input type=hidden name="itemprice" value="2.99">
  <input type=text size=2 name="itemquant" value="1">
  <input type=submit value="Add to Cart">
  </form>

Optional weight tag:
  If you will be calculating shipping charges based on weight, you need to include the
  following weight tag:

  <input type=hidden name="weight" value="enter the weight here">


