Block Up computer font created 2000 Harold Lohner

FREEWARE-Distribute freely.

Based on a "lost" Letraset font BLOCK UP, designed by Sally Ann Grover
and �1974 Letraset in the analog form.

Also available now is an original set of three fonts that can be layered to
add color to the three visible faces of the cubes.

HLohner@aol.com
http://members.aol.com/fontner

