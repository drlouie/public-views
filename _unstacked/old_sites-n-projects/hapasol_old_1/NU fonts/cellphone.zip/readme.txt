A KLUDO STUDIOS TYPEFACE
========================


USAGE

This font was designed by James Helps of Kludo Studios, 
and is free to use for personal use. If you wish to use
this font commercially please contact Kludo Studios at 
type@kludo.co.uk. 

This font can also be supplied as Type 1 for the PC or
the MAC.


CONTACT


Please feel free to contact the designer of this font, 
James Helps, at jihelps@yahoo.com.

If you you wish to visit the Kludo Studios web-site 
please do so at http://www.kludo.co.uk


ABOUT KLUDO TYPOGRAPICAL SERVICES

Kludo Studios has a number of years experience in the 
field of typography and offers a whole-host of typographical 
solutions to design related problems.

Tailor-made Typefaces :
If you need a type face for a unique identity we can 
supply it, taking into consideration it's usage, your type 
of business and existing identities. 

Logos : 
Kludo can create a font of line-art images that you may use 
on a regular basis in documents. This includes such items 
as signitures, symbols and company logos.

Handwritting : 
We offer the service of turning your handwritting into your 
own unique typeface.

Typesetting : If you are looking for that right look and 
feel for your design work, such as newsletters, brouchers, 
etc. Kludo can offer you a typesetting service second to none.


