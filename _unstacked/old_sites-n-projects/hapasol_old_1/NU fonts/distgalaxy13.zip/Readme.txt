------------------------------------------------------------------
DISTANT GALAXY v1.3, created by ShyWedge, 1999.
------------------------------------------------------------------

The following TrueType fonts are included:

 - Distant Galaxy 
 - Distant Galaxy, Italic
 - Distant Galaxy AltOutline
 - Distant Galaxy AltOutline, Italic
 - Distant Galaxy Condensed
 - Distant Galaxy Condensed, Italic
 - Distant Galaxy Outline
 - Distant Galaxy Outline, Italic

v1.3 UPDATES
------------------------------------------------------------------

 - Numbers and punctuation have been added.
 - Rebel Alliance insignia has been added.
 - Imperial insignia has been added.
 - Lightsaber has been added.
 - Improved lettering, spacing, and kerning.

INSTRUCTIONS
------------------------------------------------------------------

 - To connect characters using Distant Galaxy or Distant Galaxy
   Condensed, use a lowercase for the first letter to be connected
   and an uppercase for the second.

   For example, type the following line using Distant Galaxy:

   <sTar< warS>
   (note: < and > are used as extensions, see SPECIAL CHARACTERS.)

 - To connect characters using Distant Galaxy AltOutline (note:
   Distant Galaxy Outline characters do not connect and are
   designed to work with Distant Galaxy AltOutline characters),
   use a lowercase for the first letter to be connected and an
   uppercase for the second.

   For example, type the following line using Distant Galaxy
   AltOutline:

   [4Tar] war4}
   (note: [, ], and } are used as extensions and 4 is an open S,
   see SPECIAL CHARACTERS.)

SPECIAL CHARACTERS
------------------------------------------------------------------

 - Distant Galaxy, Distant Galaxy Condensed

     Rebel Alliance insignia --------------------- press @
     Imperial insignia --------------------------- press *
     Lightsaber ---------------------------------- press #
     Bottom extension ---------------------------- press <
     Top extension ------------------------------- press >

 - Distant Galaxy AltOutline

     Open E -------------------------------------- press 1
     Open L -------------------------------------- press 2
     Open R -------------------------------------- press 3
     Open S -------------------------------------- press 4
     Open T -------------------------------------- press 5
     Open Z -------------------------------------- press 6
     Open bottom extension ----------------------- press <
     Open top extension -------------------------- press >
     Closed bottom right extension --------------- press [
     Closed bottom left extension ---------------- press ]
     Closed top right extension ------------------ press {
     Closed top left extension ------------------- press }


This font package is Freeware.  If you wish to distribute it,
please include all of the above fonts along with this document
and send me an e-mail to let me know which font you have so I can
inform you of the latest updates.

Thank you for downloading this font package and enjoy!

ShyFonts by ShyWedge, 1999.
------------------------------------------------------------------
Web Site:  http://welcome.to/ShyFonts
E-mail:    ShyWedge@yahoo.com