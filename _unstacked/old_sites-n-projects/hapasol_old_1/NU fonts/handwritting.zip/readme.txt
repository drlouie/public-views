Handwriting Normal
freeware font
by Pelle Piano

http://pellepiano.just.nu

converted with permission from Mac to PC
June 1999 by Fonts & Things
http://www.fontsnthings.com/

please contact Pelle Piano for distribution terms.