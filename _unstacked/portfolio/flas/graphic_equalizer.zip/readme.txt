Flash 5 Graphic Equalizer using ActionScript
----------------------------------------------------------

++ Terms

This is given as is. Feel free to open, read and learn.

NOT to be used for commercial use. If commercial use is
desired, contact me at lmccomish@recoil-interactive.co.uk
----------------------------------------------------------

++ Use

Unzip and open the FLA in Flash 5. Code on the equalizer
movie clip is fully commented.
----------------------------------------------------------

++ Credits

Programming - Leon McComish.
contact: lmccomish@recoil-interactive.co.uk
