This is the HAMweather 2.036

########################################################
#      HAMweather License & copyright
########################################################
 This script is copyright(c) 2000 by HAMweather, LLC, all rights reserved.
 It is subject to the license agreement that can be found at the following
 URL: http://www.hamweather.com/install/licenseinfo.html

A copy of the License agreement is also included in the distribution.
In the docs directory, filename: license.html
#########################################################

########################################################
#      HAMweather Installation & Docs
########################################################
Installation and usage docs are included in the docs directory of this
distribution. Open up the index.html file in your browser.
The Docs can also be found online at:
http://www.hamweather.com/support/docs

########################################################
#      Zipcode and Extensive "Place, State" support
########################################################
It is recommended that you down load the HWzipdb add-on, which adds
zipcode support to HAMweather (any version) and the HWaltplaces add-on
will add support for most US "place, state" combinations to HAMweather
(any version)
They can be downloaded from :
http://www.hamweather.com/downloads

########################################################
#      HAMweather Support
########################################################
For support on this update or other HAMweather products
goto the HAMweather support pages at:

http://www.hamweather.com/support/




