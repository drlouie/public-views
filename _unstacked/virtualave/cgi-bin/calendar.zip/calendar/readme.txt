Calendar README

Program Copyright 1999 Matt Kruse
http://www.mattkruse.com/

For complete installation instructions, troubleshooting, etc, see:
http://www.mattkruse.com/scripts/calendar/

NOTE: It is not possible to enter recurring events at this time. This
      will be available in a future version.

QUICK INSTALL NOTES
-------------------
1. You may need to change the files from .pl to .cgi

2. You may need to change the first line of the script from
   #!/usr/bin/perl
   to some other location, if on Unix. Check with your sysadmin.

3. If you're on unix and need to change permissions, but don't
   have access to the system prompt, a program called CuteFTP will
   help you change permissions.

4. If you are getting "501" errors or any other Server Errors, the
   best place to start looking for help is your system admin.
   Usually, this is a configuration problem with your server and not
   something I can help you fix.

Good luck!
