tkcDataGrid Component
by Tim Chung
September 13, 2002
tkc@cruddog.com

tkcDataGrid displays data from an Actionscript Recordset object, in a tabled
display, listed either horizontally or vertically depending on the choice of
the user

this is meant as a simple alternative to Macromedia's Datagrid component,
which is much more powerful than this, but this is free :))

*you must have NetServices.as installed in Flash MX to recompile the .fla