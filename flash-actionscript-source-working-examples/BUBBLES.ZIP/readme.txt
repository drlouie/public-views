Flame Effect
------------

  Do with it what you like, its public domain.  It shouldn't be
 too hard to figure out.  You can change the amount of Flame
 Particals in the last frame of the scene.  Enjoy.

  -Derrick Staples
   -Sole@antisocial.com

