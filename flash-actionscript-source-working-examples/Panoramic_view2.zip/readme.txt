The vr.fla file is a Flash 5 file u can edit it 
with Flash 5. U can export the file as flash 4
there are no scripts that are not supported at
flash 4. i recomend u to do so (because of there
flash 4 plug-in is more popular). if u have 
some question ask them the same way. Further
instructions are plased to fla file. 

By the way, my english is much terrible from
yours. :)

Good Luck

a Friend