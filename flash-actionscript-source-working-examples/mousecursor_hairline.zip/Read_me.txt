********************************************************************************************
			     High Precision mouse cursor V1.0
********************************************************************************************

Hy guys, first of all i'll apologise for my poor English. Well this is not something new, but i came up with the idea of making something "new looking" in flash coursors (i guess?!), or at least i haven't seen anything look like this in flash.
Well i just hope you enjoy it and you use it. If you decide to use it on-line, please drop me an e-mail so i can see my master piece on-line :P hehe ( Ricardoh@net.sapo.pt ).



---->I have increased the FPS to 90 so that it can be very precise.But it can also accelerate your movie, so be carefull.


********************************************************************************************
				      Melodram Web Designs 				     					       By
					Ricardo Henriques
********************************************************************************************