Scratchy Movie
A basic simulation of an old scratched and dusty film reel. The routine is provided as freeware and is as such, copyright free. Use it as you wish.

If you do use it, a credit would be nice or if you've got a flash routine that you've written and is copyright free send it to me. Fair exchange is no robbery and all that.

Thanks for using scratchy anyway.

Martyn Davies
arty_marty@m-web.co.ukwww.m-web.co.uk 