(�`�._ (�`�. MaskGallery .�`�) _.�`�)by Emiliano Pennisi..:::...
--------------------------------------------------------------------------------------------THIS  MOVIECLIP COULD BE USED LIKE GALLERYIT IS OPENSOURCE....BUT FROM THE POSSIBILITIES TO OTHERS TO DOWNLOAD ADDING  A LINK TO FLASHKITENJOY THISREALIZATIONS BY EMILIANO PENNISI..
--------------------------------------------------------------------------------------------
Questo Clip puo' essere usato come galleria, esso � rilasciato come opensource,ma dai la possibilit� ad altri utenti di scaricarlo, aggiungendo un link a FlashKit.
Realizzato da:

Emiliano Pennisi
Flash&Designes
http://www.peamarte.com/Business.html
http://www.peamarte.com
e_pennisi@hotmail.com
____________________________________________________________________________________________

